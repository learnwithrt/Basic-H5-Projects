const daysEl=document.getElementById("days")
const hoursEl=document.getElementById("hours")
const minutesEl=document.getElementById("minutes")
const secondsEl=document.getElementById("seconds")
const diwali="1 Nov 2021";
function count(){
    const diwaliDate=new Date(diwali);
    const today=new Date();
    const totalSeconds = Math.floor((diwaliDate-today)/1000);
    const days=Math.floor((totalSeconds/3600)/24);
    const hours=Math.floor(totalSeconds/3600)%24;
    const minutes=Math.floor((totalSeconds/60)%60);
    const seconds =totalSeconds%60;
    daysEl.innerHTML=days;
    hoursEl.innerHTML=formatTime(minutes);
    minutesEl.innerHTML=formatTime(hours);
    secondsEl.innerHTML=formatTime(seconds);
    console.log(days, hours, minutes,seconds);

}
function formatTime(time){
    return time<10?('0'+time):time
}
count();
setInterval(count, 1000);
